
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiResponse } from '../types';

const GEMINI_MODEL = 'gemini-2.5-flash';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        result: {
            type: Type.STRING,
            description: "The final numerical or short text answer. No extra words or commentary."
        },
        explanation: {
            type: Type.STRING,
            description: "A very brief, one-sentence explanation of the calculation performed."
        }
    },
    required: ["result", "explanation"]
};


export const calculateWithGemini = async (query: string): Promise<GeminiResponse> => {
    try {
        const systemInstruction = `
            You are a highly advanced calculator. Your sole purpose is to evaluate mathematical expressions, perform unit conversions, handle currency conversions, and solve complex word problems, then return the result in a structured JSON format.

            Strictly adhere to the following rules:
            1. **Primary Goal**: Calculate the final answer for the user's query.
            2. **Output Format**: ALWAYS respond with a JSON object that matches the provided schema.
            3. **Result Value**: The "result" value must be only the final numerical answer or a short, direct text answer. Do not add any extra words, prefixes, or commentary. For example, if the answer is 42, the value should be "42", not "The answer is 42".
            4. **Explanation Value**: The "explanation" should be a concise, one-sentence summary of the calculation performed. For example, "Converted 15 US Dollars to Indonesian Rupiah."
            5. **Error Handling**: If the query is nonsensical, cannot be calculated, or is not a calculation/conversion request, respond with JSON where "result" is "Error" and "explanation" is "Invalid query."
            
            Do not deviate from this JSON format.
        `;

        const response = await ai.models.generateContent({
            model: GEMINI_MODEL,
            contents: query,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema,
                temperature: 0,
            },
        });

        const jsonText = response.text.trim();
        const parsedResponse: GeminiResponse = JSON.parse(jsonText);
        return parsedResponse;
        
    } catch (error) {
        console.error('Error calling Gemini API:', error);
        return { result: 'Error', explanation: 'Failed to communicate with the API.' };
    }
};
