import React, { useState, useMemo, useCallback } from 'react';
import { CONVERSION_CATEGORIES, convert } from '../services/conversionService';
import { Unit } from '../types';

const Converter: React.FC = () => {
    const categoryNames = Object.keys(CONVERSION_CATEGORIES);
    const [activeCategory, setActiveCategory] = useState<string>(categoryNames[0]);
    
    const { units } = CONVERSION_CATEGORIES[activeCategory];
    
    const [fromUnit, setFromUnit] = useState<Unit>(units[0]);
    const [toUnit, setToUnit] = useState<Unit>(units[1]);
    const [fromValue, setFromValue] = useState<string>('1');
    const [toValue, setToValue] = useState<string>(() => convert(1, units[0], units[1]).toString());
    
    const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newCategory = e.target.value;
        setActiveCategory(newCategory);
        const newUnits = CONVERSION_CATEGORIES[newCategory].units;
        const newFromUnit = newUnits[0];
        const newToUnit = newUnits[1] || newUnits[0];
        setFromUnit(newFromUnit);
        setToUnit(newToUnit);
        setFromValue('1');
        setToValue(convert(1, newFromUnit, newToUnit).toString());
    };

    const handleUnitChange = (type: 'from' | 'to', newUnitSymbol: string) => {
        const newUnit = units.find(u => u.symbol === newUnitSymbol);
        if (!newUnit) return;

        if (type === 'from') {
            setFromUnit(newUnit);
            const result = convert(parseFloat(fromValue) || 0, newUnit, toUnit);
            setToValue(result.toString());
        } else {
            setToUnit(newUnit);
            const result = convert(parseFloat(fromValue) || 0, fromUnit, newUnit);
            setToValue(result.toString());
        }
    };
    
    const handleValueChange = (type: 'from' | 'to', value: string) => {
        const numericValue = parseFloat(value);
        if (value === '' || isNaN(numericValue)) {
            setFromValue(type === 'from' ? value : '');
            setToValue(type === 'to' ? value : '');
            return;
        }

        if (type === 'from') {
            setFromValue(value);
            const result = convert(numericValue, fromUnit, toUnit);
            setToValue(result.toString());
        } else {
            setToValue(value);
            const result = convert(numericValue, toUnit, fromUnit);
            setFromValue(result.toString());
        }
    };

    const handleSwap = () => {
        setFromUnit(toUnit);
        setToUnit(fromUnit);
        setFromValue(toValue);
        setToValue(fromValue);
    };

    const UnitSelector = ({ selectedUnit, onChange, unitList }: { selectedUnit: Unit, onChange: (symbol: string) => void, unitList: Unit[] }) => (
        <select
            value={selectedUnit.symbol}
            onChange={(e) => onChange(e.target.value)}
            className="bg-[--color-buttonBackground] text-[--color-textPrimary] rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-[--color-accent]"
        >
            {unitList.map(unit => (
                <option key={unit.symbol} value={unit.symbol}>{unit.name} ({unit.symbol})</option>
            ))}
        </select>
    );

    const ConversionInput = ({ unit, onUnitChange, value, onValueChange, unitList }: { unit: Unit, onUnitChange: (symbol: string) => void, value: string, onValueChange: (value: string) => void, unitList: Unit[] }) => (
        <div className="bg-[--color-displayBackground] p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-[--color-textSecondary]">{unit.name}</span>
                <UnitSelector selectedUnit={unit} onChange={onUnitChange} unitList={unitList} />
            </div>
            <input
                type="number"
                value={value}
                onChange={(e) => onValueChange(e.target.value)}
                className="w-full bg-transparent text-4xl font-bold text-right focus:outline-none"
                placeholder="0"
            />
        </div>
    );
    
    return (
        <div className="space-y-4 min-h-[492px]">
            <select 
                value={activeCategory}
                onChange={handleCategoryChange}
                className="w-full bg-[--color-buttonBackground] text-[--color-textPrimary] rounded-lg px-4 py-3 font-bold focus:outline-none focus:ring-2 focus:ring-[--color-accent]"
            >
                {categoryNames.map(name => (
                    <option key={name} value={name}>{name}</option>
                ))}
            </select>
            
            <ConversionInput 
                unit={fromUnit}
                onUnitChange={(symbol) => handleUnitChange('from', symbol)}
                value={fromValue}
                onValueChange={(val) => handleValueChange('from', val)}
                unitList={units}
            />

            <div className="flex justify-center">
                 <button onClick={handleSwap} className="p-2 rounded-full bg-[--color-buttonBackground] hover:bg-[--color-buttonBackgroundHover] text-[--color-textSecondary] hover:text-[--color-textPrimary] transition-all transform hover:rotate-180">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M7 16V4m0 12l-4-4m4 4l4-4m6 8v-4m0 0l4-4m-4 4l-4-4" />
                    </svg>
                </button>
            </div>

             <ConversionInput 
                unit={toUnit}
                onUnitChange={(symbol) => handleUnitChange('to', symbol)}
                value={toValue}
                onValueChange={(val) => handleValueChange('to', val)}
                unitList={units}
            />
        </div>
    );
};

export default Converter;