import React, { useState } from 'react';
import { HistoryItem } from '../types';

interface DisplayProps {
    input: string;
    result: string;
    isLoading: boolean;
    isGemini: boolean;
    errorKey: number;
    history: HistoryItem[];
    onHistoryClick: (value: string) => void;
    isScientific: boolean;
    onToggleScientific: () => void;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center justify-end space-x-2">
        <div className="w-4 h-4 rounded-full bg-[--color-accent] animate-pulse"></div>
        <div className="w-4 h-4 rounded-full bg-[--color-accent] animate-pulse [animation-delay:0.2s]"></div>
        <div className="w-4 h-4 rounded-full bg-[--color-accent] animate-pulse [animation-delay:0.4s]"></div>
    </div>
);

const Display: React.FC<DisplayProps> = ({ input, result, isLoading, isGemini, errorKey, history, onHistoryClick, isScientific, onToggleScientific }) => {
    const [isCopied, setIsCopied] = useState(false);

    const handleCopy = () => {
        if (result && !isLoading && result !== 'Error' && result !== 'API Error') {
            navigator.clipboard.writeText(result).then(() => {
                setIsCopied(true);
                setTimeout(() => setIsCopied(false), 1500);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
            });
        }
    };

    const isError = !isLoading && (result === 'Error' || result === 'API Error');
    const resultFontSize = result.length > 10 ? 'text-4xl' : result.length > 7 ? 'text-5xl' : 'text-6xl';

    return (
        <div className="relative bg-[--color-displayBackground] rounded-lg px-6 py-4 mb-4 text-right break-words min-h-[220px] flex flex-col justify-end transition-colors duration-300">
             <style>{`
                @keyframes shake {
                    10%, 90% { transform: translate3d(-1px, 0, 0); }
                    20%, 80% { transform: translate3d(2px, 0, 0); }
                    30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
                    40%, 60% { transform: translate3d(4px, 0, 0); }
                }
                .animate-shake {
                    animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
                }
            `}</style>
            
            <button 
                onClick={onToggleScientific}
                className="absolute top-3 left-3 p-2 text-[--color-textSecondary] hover:text-[--color-textPrimary] transition-colors z-10"
                aria-label={isScientific ? "Collapse scientific keypad" : "Expand scientific keypad"}
                aria-expanded={isScientific}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 9l4-4 4 4m0 6l-4 4-4-4" />
                </svg>
            </button>

            <div className="flex-grow flex flex-col justify-end items-end text-lg text-[--color-textSecondary] overflow-hidden">
                {history.slice(0, 3).reverse().map((item, index) => (
                    <div key={index} className="truncate max-w-full">
                       <span className="cursor-pointer hover:text-[--color-textPrimary]" onClick={() => onHistoryClick(item.input)}>{item.input}</span>
                       <span className="text-[--color-textPrimary] font-medium"> = </span>
                       <span className="cursor-pointer hover:text-[--color-textPrimary] font-medium text-[--color-textPrimary]" onClick={() => onHistoryClick(item.result)}>{item.result}</span>
                    </div>
                ))}
            </div>

            <div className="h-8 text-2xl text-[--color-textSecondary] truncate">{input || ' '}</div>
            <div className="flex items-center justify-end gap-2">
                {!isLoading && !isError && result !== '0' && (
                     <button 
                        onClick={handleCopy} 
                        className="p-2 -ml-2 rounded-full text-[--color-textSecondary] hover:text-[--color-textPrimary] hover:bg-white/10 transition-colors"
                        aria-label="Copy result"
                     >
                        {isCopied ? (
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[--color-accent]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                            </svg>
                        )}
                    </button>
                )}
                <div key={errorKey} className={`h-16 font-bold flex items-center justify-end transition-all duration-200 ${resultFontSize} ${isError ? 'animate-shake' : ''}`}>
                    {isLoading ? (
                        <LoadingSpinner />
                    ) : isError ? (
                        <div className="flex items-center justify-end gap-2" style={{ color: 'var(--color-buttonSpecial1Background)'}}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.21 3.03-1.742 3.03H4.42c-1.532 0-2.492-1.696-1.742-3.03l5.58-9.92zM10 13a1 1 0 110-2 1 1 0 010 2zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                            </svg>
                            <span className="truncate">{result}</span>
                        </div>
                    ) : (
                        <span className="truncate">{result}</span>
                    )}
                </div>
            </div>
             {isGemini && !isLoading && !isError && (
                <div className="h-6 text-sm text-[--color-accent] font-semibold text-right mt-1 flex items-center justify-end">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm3.93 6.07L12 12l-3.93-3.93L12 4.14l3.93 3.93zM4.14 12l3.93 3.93L12 12l-3.93-3.93-3.93 3.93zm7.86 7.86L12 12l3.93 3.93L12 19.86z"></path></svg>
                    Powered by Gemini
                </div>
            )}
        </div>
    );
};

export default Display;