import React from 'react';
import Button from './Button';
import type { ButtonVariant } from './Button';

interface KeypadProps {
    onButtonClick: (value: string) => void;
    isDegrees: boolean;
    is2nd: boolean;
    isScientific: boolean;
    isListening: boolean;
}

const BackspaceIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.414 6.414a2 2 0 002.828 0L21 12M3 12l6.414-6.414a2 2 0 012.828 0L21 12" />
    </svg>
);

const MicIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
    </svg>
);


const Keypad: React.FC<KeypadProps> = ({ onButtonClick, isDegrees, is2nd, isScientific, isListening }) => {
    
    type ButtonConfig = { label: string | React.ReactNode; value: string; variant?: ButtonVariant; className?: string; active?: boolean };

    const scientificButtons: ButtonConfig[] = [
        { label: '2nd', value: '2nd', variant: 'default', active: is2nd },
        { label: 'deg', value: 'Deg', variant: 'default', active: isDegrees },
        { label: is2nd ? <span>sin<sup>-1</sup></span> : 'sin', value: 'sin', variant: 'default' },
        { label: is2nd ? <span>cos<sup>-1</sup></span> : 'cos', value: 'cos', variant: 'default' },
        { label: is2nd ? <span>tan<sup>-1</sup></span> : 'tan', value: 'tan', variant: 'default' },
        { label: <span>x<sup>y</sup></span>, value: 'x^y', variant: 'default' },
        { label: is2nd ? <span>10<sup>x</sup></span> : 'lg', value: 'lg', variant: 'default' },
        { label: is2nd ? <span>e<sup>x</sup></span> : 'ln', value: 'ln', variant: 'default' },
        { label: '(', value: '(', variant: 'default' },
        { label: ')', value: ')', variant: 'default' },
    ];
    
    const basicButtons: ButtonConfig[] = [
        { label: is2nd ? <span>x<sup>2</sup></span> : '√', value: '√', variant: 'default' },
        { label: 'AC', value: 'AC', variant: 'special1' },
        { label: <BackspaceIcon />, value: 'DEL', variant: 'special1' },
        { label: '%', value: '%', variant: 'operator' },
        { label: '÷', value: '÷', variant: 'operator' },
        { label: 'x!', value: '!', variant: 'default' },
        { label: '7', value: '7', variant: 'number' },
        { label: '8', value: '8', variant: 'number' },
        { label: '9', value: '9', variant: 'number' },
        { label: '×', value: '×', variant: 'operator' },
        { label: '1/x', value: '1/x', variant: 'default' },
        { label: '4', value: '4', variant: 'number' },
        { label: '5', value: '5', variant: 'number' },
        { label: '6', value: '6', variant: 'number' },
        { label: '-', value: '-', variant: 'operator' },
        { label: 'π', value: 'π', variant: 'default' },
        { label: '1', value: '1', variant: 'number' },
        { label: '2', value: '2', variant: 'number' },
        { label: '3', value: '3', variant: 'number' },
        { label: '+', value: '+', variant: 'operator' },
        { label: <MicIcon />, value: 'MIC', variant: 'default', active: isListening },
        { label: '0', value: '0', variant: 'number' },
        { label: '.', value: '.', variant: 'number' },
        { label: 'e', value: 'e', variant: 'default' },
        { label: '=', value: '=', variant: 'special2' },
    ];


    return (
        <div className="grid grid-cols-5 gap-3">
             <div className={`col-span-5 grid grid-cols-subgrid gap-3 transition-[grid-template-rows] duration-300 ease-in-out ${isScientific ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
                <div className="col-span-5 overflow-hidden">
                    <div className="grid grid-cols-5 gap-3">
                        {scientificButtons.map((btn, index) => (
                            <Button
                                key={btn.value + index}
                                label={btn.label}
                                onClick={() => onButtonClick(btn.value)}
                                variant={btn.variant}
                                className={btn.className}
                                isActive={btn.active}
                            />
                        ))}
                    </div>
                </div>
            </div>

            {basicButtons.map((btn, index) => (
                <Button
                    key={btn.value + index}
                    label={btn.label}
                    onClick={() => onButtonClick(btn.value)}
                    variant={btn.variant}
                    className={btn.className}
                    isActive={btn.active}
                />
            ))}
        </div>
    );
};

export default Keypad;
